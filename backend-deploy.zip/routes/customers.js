const express = require('express');
const { body } = require('express-validator');
const {
  registerCustomer,
  loginCustomer,
  getCustomerProfile,
  updateCustomerProfile,
  forgotPassword,
  resetPassword
} = require('../controllers/customerController');
const auth = require('../middleware/auth');

const router = express.Router();

// Validation middleware
const registerValidation = [
  body('username')
    .isLength({ min: 2 })
    .withMessage('Username must be at least 2 characters long')
    .trim(),
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long'),
  body('phoneNumber')
    .notEmpty()
    .withMessage('Phone number is required')
    .isMobilePhone()
    .withMessage('Please provide a valid phone number'),
  body('address')
    .notEmpty()
    .withMessage('Address is required')
    .isLength({ min: 5 })
    .withMessage('Address must be at least 5 characters long')
];

const loginValidation = [
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail(),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

const forgotPasswordValidation = [
  body('email')
    .isEmail()
    .withMessage('Please provide a valid email')
    .normalizeEmail()
];

const resetPasswordValidation = [
  body('token')
    .notEmpty()
    .withMessage('Reset token is required'),
  body('newPassword')
    .isLength({ min: 6 })
    .withMessage('New password must be at least 6 characters long')
];

// Customer registration route
router.post('/register', registerValidation, registerCustomer);

// Customer login route
router.post('/login', loginValidation, loginCustomer);

// Get customer profile (protected route)
router.get('/profile', auth, getCustomerProfile);

// Update customer profile (protected route)
router.put('/profile', auth, updateCustomerProfile);

// Forgot password route
router.post('/forgot-password', forgotPasswordValidation, forgotPassword);

// Reset password route
router.post('/reset-password', resetPasswordValidation, resetPassword);

module.exports = router;
